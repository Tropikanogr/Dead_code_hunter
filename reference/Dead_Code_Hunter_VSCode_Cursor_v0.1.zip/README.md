# Dead Code Hunter — VS Code + Cursor

Έκδοση **v0.1 — audit-only**. Κατάλληλη για Python/FastAPI, TypeScript/React και Dart/Flutter.

> **Αυτό ΔΕΝ είναι εργαλείο αυτόματης διαγραφής.** Οι στατικοί analyzers παράγουν *υποψήφια* ευρήματα, όχι εγγυημένα ασφαλείς διαγραφές.

## Εγκατάσταση στο project

Αντέγραψε στο **root του repository** τους φακέλους από το ZIP:

```text
.github/agents/dead-code-hunter.agent.md    # VS Code / Copilot
.cursor/agents/dead-code-hunter.md          # Cursor
 tools/dead_code_scan.py                    # τοπικός scanner
```

Τα αρχεία `README.md` και `tests/` είναι προαιρετικά στο δικό σου repo.

### VS Code

1. Άνοιξε το repository στον VS Code με το GitHub Copilot Chat / Agents διαθέσιμο.
2. Άνοιξε Chat, επίλεξε τον κατάλληλο harness και από τον agent picker **Dead Code Hunter**.
3. Γράψε: `Κάνε audit όλου του repository για dead code. Μόνο read-only, απόδειξη ανά εύρημα, χωρίς αλλαγές.`
4. Το agent file επιτρέπει `read`, `search`, `execute` — **όχι `edit`**. Η χρήση terminal ενδέχεται να έχει παρενέργειες, επομένως έλεγχε τις εγκρίσεις εντολών. Εάν θέλεις αυστηρότερη απομόνωση, αφαίρεσε το `execute` και τρέξε τον scanner μόνος σου.

### Cursor

1. Άνοιξε το repository στον Cursor.
2. Στο κύριο Agent chat: `/dead-code-hunter κάνε audit όλου του repository, χωρίς αλλαγές.`
3. Το υπο-agent έχει `readonly: true`, ώστε να περιορίζονται οι εγγραφές και οι state-changing εντολές. Ορισμένοι analyzers μπορεί να μη μπορούν να εκτελεστούν σε αυτό το mode· τότε τρέξε χειροκίνητα τον scanner και δώσε στον agent την έξοδο.

## Χρήση σε όλα τα repositories (global)

Μπορείς να τοποθετήσεις το `.agent.md` στο `%USERPROFILE%\.copilot\agents\` για το VS Code/Copilot και το `.md` στο `%USERPROFILE%\.cursor\agents\` για το Cursor (Windows). Ο scanner δεν εγκαθίσταται παγκόσμια: κράτησέ τον σε κάθε repo που ελέγχεις ή τρέξ' τον από το path του ZIP με `--repo`.

## Scanner από terminal

Χρειάζεται Python 3.10+ (standard library μόνο):

```powershell
py -3 tools/dead_code_scan.py --repo .
py -3 tools/dead_code_scan.py --repo . --format json
py -3 -m unittest discover -s tests -v
```

Ο scanner **χρησιμοποιεί μόνο ήδη εγκατεστημένα** εργαλεία. Δεν προσπαθεί να εγκαταστήσει dependencies ούτε να καλέσει `npx`.

| Stack | Εργαλεία που αναζητά | Εύρος |
|---|---|---|
| Python | Ruff (`F401`, `F841`), Vulture | αχρησιμοποίητα imports/variables, πιθανά unused symbols |
| TS/JS | local Knip στο `node_modules/.bin` | unused files, exports, dependencies |
| Dart/Flutter | `dart analyze` | unused diagnostics και γενικότερα analyzer findings |

- Τα εργαλεία πρέπει να έχουν εγκατασταθεί **ήδη** στο δικό σου αξιόπιστο environment.
- Εάν λείπουν, εμφανίζονται `skipped`· δεν θεωρείται "καθαρό" το project.
- Ο scanner αναζητά subprojects έως 4 επίπεδα (όρισε `--max-depth`/`--max-projects` αν χρειάζεται).
- Τα JSON/text outputs έχουν όριο μήκους ανά εργαλείο. Εμφανίζεται προειδοποίηση `truncated` αν λείπει τμήμα.
- Κωδικοί εξόδου από analyzers με ευρήματα δεν είναι πάντα failure. Το Knip π.χ. επιστρέφει `1` όταν εντοπίσει προβλήματα.
- **Προσοχή:** Ανάλυση κώδικα μπορεί να φορτώσει repository config ή να δημιουργήσει caches, ανάλογα με το εργαλείο. Χρησιμοποίησέ το μόνο σε trusted checkout και έλεγχε το `git status` πριν και μετά.
- Ο scanner δεν υποστηρίζει/δεν εγγυάται πλήρη ανίχνευση για runtime registrations, dynamic imports, API consumers, migrations, generated code ή άλλα frameworks. Εκεί χρειάζεται manual review από τον agent.
- Το `Vulture` μπορεί να έχει false positives σε Python frameworks/decorators. Το `Knip` χρειάζεται σωστά entrypoints/config σε monorepos.

## Αξιολόγηση κάθε ευρήματος

- **A**: ισχυρός υποψήφιος για καθαρισμό, αφού ελεγχθούν οι εξαρτήσεις.
- **B**: αβέβαιο· χρειάζεται περισσότερη έρευνα.
- **C**: πιθανό false positive ή κώδικας που πρέπει να παραμείνει.

Για κάθε εύρημα ο agent οφείλει να παρουσιάσει αρχείο/γραμμή, αποδεικτικά στοιχεία, επίπεδο ρίσκου και προτεινόμενα tests. **Καμία διαγραφή σε αυτό το στάδιο.**

## Ειδικά για production projects

Πριν διαγράψεις οτιδήποτε σχετικό με authentication, OAuth, DB migrations, τιμολόγηση/ΦΠΑ, multi-tenant πρόσβαση, API endpoints, integrations, Flutter lifecycle/notifications, background jobs ή παλαιά callbacks, χρειάζεται explicit risk review και test plan. Η μη ύπαρξη αναφοράς σε αναζήτηση text δεν αποδεικνύει μη χρήση στην παραγωγή.

## Επίσημες πηγές (format/tool reference)

- VS Code: https://code.visualstudio.com/docs/agent-customization/custom-agents
- VS Code file reference: https://code.visualstudio.com/docs/agents/reference/custom-agent-file-reference
- Cursor: https://cursor.com/docs/subagents
- Knip: https://knip.dev/reference/cli
- Vulture: https://pypi.org/project/vulture/
- Dart analyzer: https://dart.dev/tools/dart-analyze
