#!/usr/bin/env python3
"""Read-only *source* dead-code candidate scan, using only installed local tools.

No network access or automatic installs. Tools may write caches or run repository
configuration code: execute on trusted local checkouts only. Never auto-delete.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

SKIP = {
    ".git", ".venv", "venv", "env", "node_modules", ".next", ".nuxt",
    "dist", "build", ".dart_tool", ".idea", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".tox", "coverage", ".gradle", ".flutter-plugins",
    "Pods", "__pycache__", ".turbo", ".output", ".git-worktrees",
}
PY_MARKERS = {"pyproject.toml", "setup.py", "requirements.txt", "Pipfile"}
JS_MARKERS = {"package.json"}
DART_MARKERS = {"pubspec.yaml"}
OUTPUT_LIMIT = 15000


def detect_projects(root: Path, max_depth: int = 4, max_projects: int = 20) -> list[tuple[Path, set[str]]]:
    """Detect supported project roots, without reading source or following symlinks."""
    found = []
    for where, dirs, files in os.walk(root, followlinks=False):
        parent = Path(where)
        depth = len(parent.relative_to(root).parts)
        dirs[:] = [d for d in dirs if d not in SKIP and not (parent / d).is_symlink()]
        if depth >= max_depth:
            dirs[:] = []
        names = set(files)
        langs: set[str] = set()
        if names & JS_MARKERS:
            langs.add("ts-js")
        if names & PY_MARKERS or (parent == root and any(p.suffix == ".py" for p in parent.iterdir() if p.is_file())):
            langs.add("python")
        if names & DART_MARKERS:
            langs.add("dart")
        if langs:
            found.append((parent, langs))
            if len(found) >= max_projects:
                break
    return found


def find_tool(name: str, project: Path, root: Path) -> str | None:
    """Prefer project-local tools; never download executables."""
    folder = project
    while True:
        candidates = []
        if name == "knip":
            candidates = [folder / "node_modules" / ".bin" / "knip", folder / "node_modules" / ".bin" / "knip.cmd"]
        elif name in ("ruff", "vulture"):
            candidates = [folder / ".venv" / "bin" / name,
                          folder / ".venv" / "Scripts" / (name + ".exe")]
        for candidate in candidates:
            if candidate.is_file():
                return str(candidate)
        if folder == root or folder.parent == folder or not folder.is_relative_to(root):
            break
        folder = folder.parent
    if name == "knip":
        return None  # A global Knip installation may not match workspace config.
    return shutil.which(name)


def run_command(args: list[str], cwd: Path, timeout: int) -> dict[str, Any]:
    env = dict(os.environ)
    env.update({"CI": "1", "npm_config_offline": "true", "NO_COLOR": "1", "RUFF_NO_CACHE": "1"})
    try:
        completed = subprocess.run(
            args, cwd=cwd, env=env, capture_output=True, text=True, errors="replace",
            timeout=timeout, shell=False, check=False,
        )
        combined = (completed.stdout or "") + ("\n[stderr]\n" + completed.stderr if completed.stderr else "")
        truncated = len(combined) > OUTPUT_LIMIT
        return {"status": "executed", "exit_code": completed.returncode,
                "output": combined[:OUTPUT_LIMIT], "truncated": truncated}
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "timeout_seconds": timeout, "output": ""}
    except (OSError, ValueError) as exc:
        return {"status": "error", "error": str(exc), "output": ""}


def git_status(root: Path) -> dict[str, Any]:
    git = shutil.which("git")
    if not git:
        return {"status": "unavailable"}
    result = run_command([git, "status", "--porcelain=v1", "--untracked-files=normal"], root, 15)
    if result.get("exit_code") != 0:
        return {"status": "not-git-or-unavailable", "details": result.get("output", "")[:200]}
    return {"status": "ok", "porcelain": result["output"]}


def scan(root: Path, timeout: int, max_depth: int, max_projects: int) -> dict[str, Any]:
    before = git_status(root)
    projects = detect_projects(root, max_depth=max_depth, max_projects=max_projects)
    reports: list[dict[str, Any]] = []
    for project, langs in projects:
        found: dict[str, Any] = {"path": str(project.relative_to(root) or "."), "languages": sorted(langs), "checks": []}
        def check(name: str, command: list[str] | None, note: str) -> None:
            if command is None:
                found["checks"].append({"name": name, "status": "skipped", "reason": note})
                return
            result = run_command(command, project, timeout)
            found["checks"].append({"name": name, "command": command, **result})

        if "ts-js" in langs:
            knip = find_tool("knip", project, root)
            check("Knip", [knip, "--reporter", "json"] if knip else None,
                  "Knip is not locally installed (node_modules/.bin/knip).")
        if "python" in langs:
            ruff = find_tool("ruff", project, root)
            vulture = find_tool("vulture", project, root)
            check("Ruff F401/F841", [ruff, "check", ".", "--select", "F401,F841", "--no-cache", "--output-format", "json"] if ruff else None,
                  "Ruff is not installed locally or on PATH.")
            # Scan the whole Python project, including nonstandard package folders;
            # omit dependency/generated trees and this audit helper if copied in.
            check("Vulture", [vulture, ".", "--min-confidence", "60", "--exclude", ".venv/,venv/,build/,dist/,node_modules/,.git/,.dart_tool/,tools/dead_code_scan.py"] if vulture else None,
                  "Vulture is not installed locally or on PATH.")
        if "dart" in langs:
            dart = find_tool("dart", project, root)
            check("Dart analyze", [dart, "analyze"] if dart else None,
                  "Dart SDK is not installed/on PATH.")
        reports.append(found)
    after = git_status(root)
    delta = None
    if before.get("status") == after.get("status") == "ok":
        delta = before["porcelain"] != after["porcelain"]
    return {
        "repository": str(root),
        "note": "Candidate detection only; never proof that code is safe to delete. No automatic fixes or installs.",
        "projects_found": len(projects), "project_limit_reached": len(projects) >= max_projects,
        "git_before": before, "git_after": after, "git_status_changed": delta,
        "projects": reports,
    }


def as_text(data: dict[str, Any]) -> str:
    out = [f"Dead Code Hunter scan — {data['repository']}", data["note"],
           f"Detected projects: {data['projects_found']}",
           f"Git status changed during scan: {data['git_status_changed']}"]
    if data["project_limit_reached"]:
        out.append("WARNING: Project limit reached; scan may be incomplete.")
    for proj in data["projects"]:
        out.append(f"\n== {proj['path']} ({', '.join(proj['languages'])}) ==")
        for check in proj["checks"]:
            out.append(f"\n-- {check['name']}: {check['status']} (exit={check.get('exit_code', 'n/a')})")
            if check.get("reason"):
                out.append("Reason: " + check["reason"])
            if check.get("command"):
                out.append("Command: " + " ".join(check["command"]))
            if check.get("output"):
                out.append(check["output"])
            if check.get("truncated"):
                out.append("WARNING: Output truncated; do not claim full finding coverage.")
    if data["git_status_changed"]:
        out.append("WARNING: Git status changed. Inspect without attempting auto-revert.")
    return "\n".join(out)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path("."), help="Trusted repository root")
    parser.add_argument("--timeout", type=int, default=120, help="Seconds per analyzer")
    parser.add_argument("--max-depth", type=int, default=4, help="Discovery depth")
    parser.add_argument("--max-projects", type=int, default=20, help="Discovery limit")
    parser.add_argument("--format", choices=["text", "json"], default="text")
    args = parser.parse_args(argv)
    if args.timeout < 1 or args.max_depth < 0 or args.max_projects < 1:
        parser.error("timeout and max-projects must be positive; max-depth must be nonnegative")
    root = args.repo.expanduser().resolve()
    if not root.is_dir():
        parser.error("--repo must be an existing directory")
    result = scan(root, args.timeout, args.max_depth, args.max_projects)
    print(json.dumps(result, ensure_ascii=False, indent=2) if args.format == "json" else as_text(result))
    return 0 if not result["git_status_changed"] else 2


if __name__ == "__main__":
    sys.exit(main())
