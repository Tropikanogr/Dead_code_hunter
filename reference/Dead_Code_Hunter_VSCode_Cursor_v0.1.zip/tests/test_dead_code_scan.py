"""Minimal dependency-free regression tests for local discovery and safety behavior."""
import importlib.util
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1] / "tools" / "dead_code_scan.py"
spec = importlib.util.spec_from_file_location("dead_code_scan", HERE)
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)


class ScanTests(unittest.TestCase):
    def test_project_discovery_skips_dependencies(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "package.json").write_text("{}")
            (root / "backend").mkdir()
            (root / "backend" / "pyproject.toml").write_text("[project]\nname='x'\n")
            (root / "node_modules").mkdir()
            (root / "node_modules" / "package.json").write_text("{}")
            found = scanner.detect_projects(root)
            self.assertEqual([(str(p.relative_to(root)), langs) for p, langs in found],
                             [(".", {"ts-js"}), ("backend", {"python"})])

    def test_missing_tools_skipped_without_running_subprocess(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "package.json").write_text("{}")
            with patch.object(scanner, "git_status", return_value={"status": "unavailable"}), \
                 patch.object(scanner, "find_tool", return_value=None), \
                 patch.object(scanner, "run_command") as runner:
                result = scanner.scan(root, 10, 3, 10)
                self.assertEqual(result["projects"][0]["checks"][0]["status"], "skipped")
                runner.assert_not_called()

    def test_ruff_command_has_no_fix_flags(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "pyproject.toml").write_text("[project]\nname='x'\n")
            with patch.object(scanner, "git_status", return_value={"status": "unavailable"}), \
                 patch.object(scanner, "find_tool", side_effect=lambda n, *a: "ruff" if n == "ruff" else None), \
                 patch.object(scanner, "run_command", return_value={"status": "executed", "exit_code": 0, "output": ""}) as runner:
                scanner.scan(root, 10, 3, 10)
                arguments = runner.call_args.args[0]
                self.assertIn("--no-cache", arguments)
                self.assertNotIn("--fix", arguments)


if __name__ == "__main__":
    unittest.main()
